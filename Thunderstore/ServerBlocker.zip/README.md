Adds a Block Server button to each entry in the lobby list.  Blocks all servers with the specified name.  Blocks carry over between sessions.  To remove blocks, simply edit or delete "blockedServerNames.json" file from the root ATLYSS directory.
Tested with BepInEx 5.
